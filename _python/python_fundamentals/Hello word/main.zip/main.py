# Task #1: Print "Hello World"
print("Hello World")

# Task #2a: Store your name in a variable and print it using a comma
your_name = "John"
print("Hello", your_name, "!")

# Task #2b: Store your name in a variable and print it using a plus sign
your_name = "John"
print("Hello " + your_name + "!")

# Task #3a: Store your favorite number in a variable and print it using a comma
favorite_num = 7
print("Hello", favorite_num, "!")

# Task #3b: Store your favorite number in a variable and print it using a plus sign
favorite_num = 7
print("Hello " + str(favorite_num) + "!")

# Task #4a: Store your favorite foods in variables and print with format method
food_one = "Pizza"
food_two = "Sushi"
print("I love to eat {} and {}.".format(food_one, food_two))

# Task #4b: Store your favorite foods in variables and print with f-strings
food_one = "Pizza"
food_two = "Sushi"
print(f"I love to eat {food_one} and {food_two}.")
